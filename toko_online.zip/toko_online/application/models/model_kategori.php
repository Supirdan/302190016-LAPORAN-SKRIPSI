<?php

class Model_kategori extends CI_Model
{
    public function data_parcel()
    {
        return $this->db->get_where("tb_barang", array('kategori' => 'parcel'));
    }

    public function data_buket()
    {
        return $this->db->get_where("tb_barang", array('kategori' => 'buket'));
    }

    public function data_snack_cake()
    {
        return $this->db->get_where("tb_barang", array('kategori' => 'snack cake'));
    }
}
