<div class="container-fluid">
    <button class="btn btn-sm btn-primary mb-3" data-toggle="modal" data-target="#tambah_iklan"><i class="fas fa-plus fa-sm"></i> Tambah Iklan</button>

    <table class="table table-bordered">
        <tr>
            <th>NO</th>
            <th>NAMA IKLAN</th>
            <th>NAMA GAMBAR</th>
            <th colspan="3">AKSI</th>
        </tr>

        <?php
        $no = 1;
        foreach ($iklan as $ikl) : ?>

            <tr>
                <td><?php echo $no++ ?></td>
                <td><?php echo $ikl->nama_ikl ?></td>
                <td><?php echo $ikl->gambar ?></td>

                <td>
                    <?php echo anchor('admin/data_iklan/edit/' . $ikl->id_ikl, '<div class="btn btn-primary btn-sm"><i class="fas fa-edit" style="color: #ffffff;"></i>') ?>
                </td>

                <td onclick="javascript: return confirm('Anda yakin hapus?')">
                    <?php echo anchor('admin/data_iklan/hapus/' . $ikl->id_ikl, '<div class="btn btn-danger btn-sm"><i class="fas fa-trash" style="color: #ffffff;"></i>') ?>
                </td>
            </tr>

        <?php endforeach; ?>

    </table>
</div>

<!-- Modal -->
<div class="modal fade" id="tambah_iklan" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">FORM IKLAN</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo base_url() . 'admin/data_iklan/tambah_aksi'; ?>" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label>Nama Iklan</label>
                        <input type="text" name="nama_ikl" class="form-control">
                    </div>

                    <div class="form-group">
                        <label>Gambar Produk</label><br>
                        <input type="file" name="gambar" class="form-control">
                    </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
            </div>

            </form>

        </div>
    </div>
</div>