<div class="container-fluid">
    <h3><i class="fas fa-edit"></i>EDIT IKLAN</h3>

    <?php foreach ($iklan as $ikl) : ?>

        <form method="post" action=" <?php echo base_url() . 'admin/data_iklan/update' ?>">

            <div class="for-group">
                <label>Nama iklan</label>
                <input type="text" name="nama_ikl" class="form-control" value="<?php echo $ikl->nama_ikl ?>">
            </div>
            <div class="for-group">
                <label>gambar</label>
                <input type="text" name="gambar" class="form-control" value="<?php echo $ikl->gambar ?>">
            </div>

            <button type="submit" class="btn btn-primary btn-sm mt-3">Simpan</button>

        </form>

    <?php endforeach; ?>

</div>