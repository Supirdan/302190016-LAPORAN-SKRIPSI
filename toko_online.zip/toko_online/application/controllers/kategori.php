<?php

class Kategori extends CI_Controller
{
    public function parcel()
    {
        $data['iklan'] = $this->db->query("SELECT * from tb_iklan")->result();
        $data['parcel'] = $this->model_kategori->data_parcel()->result();
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('parcel', $data);
        $this->load->view('templates/footer');
    }

    public function buket()
    {
        $data['buket'] = $this->model_kategori->data_buket()->result();
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('buket', $data);
        $this->load->view('templates/footer');
    }

    public function snack_cake()
    {
        $data['snack_cake'] = $this->model_kategori->data_snack_cake()->result();
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('snack_cake', $data);
        $this->load->view('templates/footer');
    }
}
