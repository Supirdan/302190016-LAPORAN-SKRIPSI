<?php

class Data_iklan extends CI_Controller
{

    public function index()
    {
        $data['iklan'] = $this->model_iklan->tampil_data()->result();
        $this->load->view('templates_admin/header');
        $this->load->view('templates_admin/sidebar');
        $this->load->view('admin/data_iklan', $data);
        $this->load->view('templates_admin/footer');
    }

    public function tambah_aksi()
    {
        $nama_ikl       = $this->input->post('nama_ikl');
        $gambar         = $_FILES['gambar']['name'];
        if ($gambar = "") {
        } else {
            $config['upload_path'] = './iklan';
            $config['allowed_types'] = 'jpg|jpeg|png|gif';

            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('gambar')) {
                echo "Gambar Gagal diUpload!";
            } else {
                $gambar = $this->upload->data('file_name');
            }
        }

        $data = array(
            'nama_ikl'      => $nama_ikl,
            'gambar'        => $gambar
        );

        $this->model_iklan->tambah_iklan($data, 'tb_iklan');
        redirect('admin/data_iklan/index');
    }

    public function edit($id)
    {
        $where = array('id_ikl' => $id);
        $data['iklan'] = $this->model_iklan->edit_iklan($where, 'tb_iklan')->result();
        $this->load->view('templates_admin/header');
        $this->load->view('templates_admin/sidebar');
        $this->load->view('admin/edit_iklan', $data);
        $this->load->view('templates_admin/footer');
    }

    public function update()
    {
        $id             = $this->input->post('id_ikl');
        $nama_ikl       = $this->input->post('nama_ikl');
        $gambar           = $this->input->post('gambar');

        $data = array(

            'nama_ikl'      => $nama_ikl,
            'gambar'          => $gambar
        );

        $where = array(
            'id_ikl' => $id
        );

        $this->model_iklan->update_data($where, $data, 'tb_iklan');
        redirect('admin/data_iklan/index');
    }

    public function hapus($id)
    {
        $where = array('id_ikl' => $id);
        $this->model_iklan->hapus_data($where, 'tb_iklan');
        redirect('admin/data_iklan/index');
    }
}
